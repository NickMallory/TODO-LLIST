//
//  ViewController.swift
//  ToDo
//
//  Created by Nick Chiloane on 2021/09/15.
//

import UIKit
import CoreData
import LKAlertController

class ToDoViewController: UITableViewController {
    private var selectedPriority: Priority!
    public var completion: ((String, String, Date) -> Void)?

    var items = [Item]()
    var taskPri:String?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadItems()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
        
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Item", for: indexPath) as! TaskTableViewCell
        let item = items[indexPath.row]
        cell.titleLabel?.text = item.name
        cell.descriptionLabel?.text = item.taskDescription
        taskPri = returnPriority(item.priority)
        cell.priorityLabel?.text = taskPri
        switch taskPri {
        case "High":
            cell.priorityLabel.textColor = UIColor.red
        case "Medium":
            cell.priorityLabel.textColor = UIColor.orange
        case "Low":
            cell.priorityLabel.textColor = UIColor.green
        default:
            print("Error setting colors")
        }
        cell.accessoryType = item.completed ? .checkmark : .none
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        items[indexPath.row].completed = !items[indexPath.row].completed
        
        saveItems()
    }
     
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            let item = items[indexPath.row]
            items.remove(at: indexPath.row)
            context.delete(item)
            
            do{
                try context.save()
            }catch{
                print("Error deleting item with \(error)")
            }
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }
        }
    
    @IBAction func addButtonPressed(_ sender: Any) {
        
        performSegue(withIdentifier: "Add", sender: false)
 
}
    
    func returnPriority(_ thePriority: Int16) ->String
    {
        var taskPriority:String  = ""
        switch thePriority {
        case 0:
            taskPriority = "High"
        case 1:
            taskPriority = "Medium"
        case 2:
            taskPriority = "Low"
        default:
            taskPriority = "N/A"
        }
        return taskPriority
    }
    
    func saveItems() {
        
        do{
        try context.save()
        }catch{
            print("error saving item with \(error)")
        }
        tableView.reloadData()
    }

    
    
    func loadItems(){
            let request: NSFetchRequest<Item> = Item.fetchRequest()
            
            do{
                items = try context.fetch(request)
            }catch{
                print("Error fetching data from context \(error)")
            }
            tableView.reloadData()
        }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DetailsViewController {
//            destination.nameLbl = items[(tableView.indexPathForSelectedRow?.row)]
            destination.item = sender as? Item
        }
    
    }
    
    
}
