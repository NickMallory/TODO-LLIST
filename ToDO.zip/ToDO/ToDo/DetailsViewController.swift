//
//  DetailsViewController.swift
//  ToDo
//
//  Created by Nick Chiloane on 2021/09/27.
//

import UIKit

class DetailsViewController: UIViewController {
    private var selectedPriority: Priority!
    var item : Item?
    var itemTask = [Item]()

    @IBAction func saveButton(_ sender: Any) {
        
        let newItem = Item(context: context) //The context from line 20
        if let taskD = taskDescription.text, let taskDn = taskName.text{
            
            newItem.name = taskDn
            
            newItem.taskDescription = taskD
            
            newItem.completed = false
            
            newItem.priority = Int16(selectedPriority.rawValue)
            
            print("The selectedPriority.rawValue is \(Int16(selectedPriority.rawValue))")
            
        }
//        newItem.name
        
        do
        {
            try context.save()
            self.navigationController?.popViewController(animated: true)
            print("Task Saved")
        }
        catch
        {
            print("Save Error: \(error.localizedDescription)")
        }
        
     
        
    }
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var taskName: UITextField!
    @IBOutlet weak var taskDescription: UITextField!
    @IBOutlet var priorityButton: [UIButton]!
    @IBAction func highButton(_ sender: Any) {
        self.setPriorityButtonBackgroundColor(atIndex: 0, color: Priority.High.color)
                self.selectedPriority = .High
    }
    @IBAction func mediumButton(_ sender: Any) {
        self.setPriorityButtonBackgroundColor(atIndex: 1, color: Priority.Medium.color)
                self.selectedPriority = .Medium
    }
    @IBAction func lowButton(_ sender: Any) {
        self.setPriorityButtonBackgroundColor(atIndex: 2, color: Priority.Low.color)
                self.selectedPriority = .Low
    }
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func addTask( _ itemID: String)
        {
            
           
        }
    private func setPriorityButtonBackgroundColor(atIndex index: Int, color: UIColor) {
            let range = 0 ..< self.priorityButton.count
            let filteredIndexes = range.filter { currentIndex in
                return currentIndex != index
            }
            
            let button = self.priorityButton[index]
            UIView.animate(withDuration: 0.5) {
                button.backgroundColor = color
            }
            
            for index in filteredIndexes {
                let button = self.priorityButton[index]
                UIView.animate(withDuration: 0.5) {
                    button.backgroundColor = #colorLiteral(red: 0.703534755, green: 0.7368400091, blue: 0.7732545685, alpha: 1)
                    
                     
                }
            }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
