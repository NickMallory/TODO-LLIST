//
//  Priorities.swift
//  ToDo
//
//  Created by Nick Chiloane on 2021/10/04.
//

import Foundation
import UIKit
enum Priority:Int {
  case High
  case Medium
  case Low
  
  public var color: UIColor {
    get {
      switch self {
      case .High:
        return UIColor.red
      case .Medium:
        return UIColor.orange
      case .Low:
        return UIColor.green
      
      }
    }
  }
  public var text: String {
    get {
      switch self {
      case .High:
        return "High"
      case .Medium:
        return "Normal"
      case .Low:
        return "Low"
    
      }
    }
  }
}




















