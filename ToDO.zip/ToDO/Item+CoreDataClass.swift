//
//  Item+CoreDataClass.swift
//  ToDo
//
//  Created by Nick Chiloane on 2021/09/28.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
